$(document).ready(function(){
	$('.button_left_menu').click(function(){
		$('.left_menu').animate({
			marginLeft : '0'
		},400);

	});

	$('.left_menu').mouseleave(function(){
		$('.left_menu').animate({
			marginLeft : '-50%'
		},500);
	});
});