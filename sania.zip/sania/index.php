﻿<!DOCTYPE html>
<html>
<head>
	<script type="text/javascript" src="script/jquery-3.3.1.js"></script>
	<script type="text/javascript" src="script/index.js"></script>
	<link rel="stylesheet" type="text/css" href="style/index.css">
	<title>Tzofim</title>
<link rel="import" href="main.php" class="'content_l">
</head>
<body>
	<div class="header">
		<p class="header_text">Tzofim</p>
	</div>

<img src="image/button.png" class="button_left_menu">

	<div class="left_menu">
		<p class="">Главная</p>
	</div>

	<div class="content_name">Главная</div>
		
		<script type="text/javascript">
			var link = document.querySelector('link[rel=import]');
			var content = link.import.querySelector('#content');
			document.body.appendChild(content.cloneNode(true));
		</script>


</body>
</html>